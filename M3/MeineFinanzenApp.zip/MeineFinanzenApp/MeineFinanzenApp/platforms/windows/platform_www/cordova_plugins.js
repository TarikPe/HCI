cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "plugins/cordova-plugin-console/www/logger.js",
        "id": "cordova-plugin-console.logger",
        "pluginId": "cordova-plugin-console",
        "clobbers": [
            "cordova.logger"
        ]
    },
    {
        "file": "plugins/cordova-plugin-console/www/console-via-logger.js",
        "id": "cordova-plugin-console.console",
        "pluginId": "cordova-plugin-console",
        "clobbers": [
            "console"
        ]
    },
    {
        "file": "plugins/cordova-plugin-device/www/device.js",
        "id": "cordova-plugin-device.device",
        "pluginId": "cordova-plugin-device",
        "clobbers": [
            "device"
        ]
    },
    {
        "file": "plugins/cordova-plugin-device/src/windows/DeviceProxy.js",
        "id": "cordova-plugin-device.DeviceProxy",
        "pluginId": "cordova-plugin-device",
        "merges": [
            ""
        ]
    },
    {
        "file": "plugins/cordova-plugin-statusbar/www/statusbar.js",
        "id": "cordova-plugin-statusbar.statusbar",
        "pluginId": "cordova-plugin-statusbar",
        "clobbers": [
            "window.StatusBar"
        ]
    },
    {
        "file": "plugins/cordova-plugin-statusbar/src/windows/StatusBarProxy.js",
        "id": "cordova-plugin-statusbar.StatusBarProxy",
        "pluginId": "cordova-plugin-statusbar",
        "runs": true
    },
    {
        "file": "plugins/ionic-plugin-keyboard/src/windows/KeyboardProxy.js",
        "id": "ionic-plugin-keyboard.KeyboardProxy",
        "pluginId": "ionic-plugin-keyboard",
        "clobbers": [
            "cordova.plugins.Keyboard"
        ],
        "runs": true
    },
    {
        "file": "plugins/cordova-plugin-websql/www/WebSQL.js",
        "id": "cordova-plugin-websql.WebSQL",
        "pluginId": "cordova-plugin-websql",
        "merges": [
            "window"
        ]
    },
    {
        "file": "plugins/cordova-plugin-websql/www/windows/Database.js",
        "id": "cordova-plugin-websql.Database",
        "pluginId": "cordova-plugin-websql"
    },
    {
        "file": "plugins/cordova-plugin-websql/www/windows/SqlTransaction.js",
        "id": "cordova-plugin-websql.SqlTransaction",
        "pluginId": "cordova-plugin-websql"
    },
    {
        "file": "plugins/cordova-plugin-websql/src/windows/WebSqlProxy.js",
        "id": "cordova-plugin-websql.WebSqlProxy",
        "pluginId": "cordova-plugin-websql",
        "runs": true
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "cordova-plugin-console": "1.0.3",
    "cordova-plugin-device": "1.1.2",
    "cordova-plugin-statusbar": "2.1.3",
    "cordova-plugin-whitelist": "1.2.2",
    "ionic-plugin-keyboard": "1.0.9",
    "cordova-plugin-websql": "0.0.10"
};
// BOTTOM OF METADATA
});