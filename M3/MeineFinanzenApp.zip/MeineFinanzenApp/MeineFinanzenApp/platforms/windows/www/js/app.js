var db = null;

var main=angular.module('starter', ['ionic', 'starter.controllers', 'ngMaterial', 'ngTagsInput', 'ngCordova'])

.run(function ($ionicPlatform, $cordovaSQLite) {
  $ionicPlatform.ready(function() {
    if (cordova.platformId === 'ios' && window.cordova && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);

    }
    if (window.StatusBar) {
      StatusBar.styleDefault();
    }

    db = $cordovaSQLite.openDB({ name: 'meineFinanzen.db', location: 'default' }, successcb, errorcb);
    $cordovaSQLite.execute(db, "CREATE TABLE IF NOT EXISTS expense (id integer primary key, paymentType text, amount text, tags text, date text)");

  });
})

.config(function($stateProvider, $urlRouterProvider) {
  $stateProvider

    .state('app', {
    url: '/app',
    abstract: true,
    templateUrl: 'templates/menu.html'
  })

  .state('app.income', {
    url: '/income',
    views: {
      'menuContent': {
          templateUrl: 'templates/income.html'
      }
    }
  })

  .state('app.expense', {
      url: '/expense',
      views: {
        'menuContent': {
            templateUrl: 'templates/expense.html',
            controller: 'expenseCtrl',
        }
      }
    })
    .state('app.advisor', {
        url: '/advisor',
      views: {
        'menuContent': {
            templateUrl: 'templates/advisor.html',
        }
      }
    })

  .state('app.profiles', {
      url: '/profiles',
    views: {
      'menuContent': {
          templateUrl: 'templates/profiles.html',
      }
    }
  })
      .state('app.savings', {
          url: '/savings',
          views: {
              'menuContent': {
                  templateUrl: 'templates/savings.html',
              }
          }
      })
  .state('app.reports', {
      url: '/reports',
      views: {
          'menuContent': {
              templateUrl: 'templates/reports.html',
          }
      }
  });
  // if none of the above states are matched, use this as the fallback
  $urlRouterProvider.otherwise('/app/expense');
});


function successcb ()
{

}

function errorcb() {

}


main.controller("sqlCtrl", function ($scope, $cordovaSQLite) {

    $scope.insert = function (paymentType, amount, tags, date) {
        var query = "INSERT INTO expense (paymentType, amount, tags, date) VALUES (?,?)";
        $cordovaSQLite.execute(db, query, [firstname, lastname]).then(function (res) {
            console.log("INSERT ID -> " + res.insertId);
        }, function (err) {
            console.error(err);
        });
    }

    $scope.select = function (lastname) {
        var query = "SELECT firstname, lastname FROM people WHERE lastname = ?";
        $cordovaSQLite.execute(db, query, [lastname]).then(function (res) {
            if (res.rows.length > 0) {
                console.log("SELECTED -> " + res.rows.item(0).firstname + " " + res.rows.item(0).lastname);
            } else {
                console.log("No results found");
            }
        }, function (err) {
            console.error(err);
        });
    }

});