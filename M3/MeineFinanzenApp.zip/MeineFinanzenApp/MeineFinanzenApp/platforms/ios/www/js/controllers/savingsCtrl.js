﻿var incomeCtrl = angular.module('starter.savingsCtrl', ['ngMaterial']);

var db = window.openDatabase('MeineFinanzen.db', '1.0', 'MeineFinanzen', '5 * 1024 * 1024');


incomeCtrl.controller('savingsCtrl', ['$scope', function ($scope) {
    $scope.targetDate = new Date();

    $scope.clearValue = function () {
        $scope.goal = null;
        $scope.amount = null;
    };

    $scope.save = function () {
        setTarget($scope);
        $scope.goal = null;
        $scope.amount = null;
        $scope.targetDate=new Date();
    };
}]);


//SQL Statements - nicht controller gebunden --

function setTarget($scope) {
    db.transaction(function (tx) {
        tx.executeSql("INSERT INTO savings(incomeType,amount,date) VALUES (?,?,?)", [$scope.goal, $scope.amount, $scope.targetDate], function (tx, result) {
            console.log(result);
        }, function (error) {
            console.log(error);
        });
    });
}