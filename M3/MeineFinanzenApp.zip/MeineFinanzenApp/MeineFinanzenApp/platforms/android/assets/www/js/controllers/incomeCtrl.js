﻿var incomeCtrl = angular.module('starter.incomeCtrl', ['ngMaterial']);

var db = window.openDatabase('MeineFinanzen.db', '1.0', 'MeineFinanzen', '5 * 1024 * 1024');


incomeCtrl.controller('incomeCtrl', ['$scope', function ($scope) {
    $scope.incomeDate = new Date();

    $scope.clearValue = function () {
        $scope.incomeType = {};
        $scope.amount = null;
    };

    $scope.save = function () {
        addIncome($scope);
    };
}]);


//SQL Statements - nicht controller gebunden --

function addIncome($scope, tags) {
    db.transaction(function (tx) {
        tx.executeSql("INSERT INTO income(incomeType,amount,date) VALUES (?,?,?)", [$scope.incomeType, $scope.amount, $scope.incomeDate], function (tx, result) {
            console.log(result);
        }, function (error) {
            console.log(error);
        });
    });
}