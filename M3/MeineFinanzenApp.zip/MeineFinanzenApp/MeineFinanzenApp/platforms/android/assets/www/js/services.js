﻿var db = window.openDatabase('MeineFinanzen.db', '1.0', 'MeineFinanzen', '5 * 1024 * 1024');

var app = angular.module('starter.services', []);


app.factory('sqlService', function ($q, $timeout) {

    

    var getAllExpense = function (startDate,endDate) {

        var deferred = $q.defer();

        $timeout(function () {
            db.transaction(function (tx) {
                tx.executeSql('SELECT * FROM expense where date between "' + startDate + '"and"' + endDate+'"', [], function (tx, result) {
                    deferred.resolve(result);
                });
            });
        }, 500);
        return deferred.promise;
    };

    return {
        getAllExpense: getAllExpense
    };

});


