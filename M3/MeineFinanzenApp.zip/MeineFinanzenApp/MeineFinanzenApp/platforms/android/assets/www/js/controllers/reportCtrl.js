﻿var reportCtrl = angular.module('starter.reportCtrl', ['ngMaterial', 'googlechart', 'starter.services']);
var db = window.openDatabase('MeineFinanzen.db', '1.0', 'MeineFinanzen', '5 * 1024 * 1024');


reportCtrl.controller('reportCtrl', function ($scope, sqlService) {
    
    $scope.hideReport = true;

    $scope.createReport = function () {

        var st = $scope.startDate;
        var startDate = st.getFullYear() + '/' + st.getMonth() + '/' + st.getDate();

        var ed = $scope.endDate;
        var endDate = ed.getFullYear() + '/' + ed.getMonth() + '/' + ed.getDate();

        reportExpenses($scope, sqlService,startDate, endDate);
    };

  }).value('googleChartApiConfig', {
      version: '1.1',
      optionalSettings: {
          packages: ['bar'],
          language: 'en'
      }
  })

function reportExpenses($scope, sqlService, startDate, endDate) {


    sqlService.getAllExpense(startDate, endDate).then(function (result) {
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Tags');
        data.addColumn('number', 'Amount');

        for (i = 0; i < result.rows.length; ++i) {
            data.addRows([
                    [result.rows[i].tags, parseFloat(result.rows[i].amount)],
            ]);
        }


        var reportChart = {};
        reportChart.type = $scope.reportType;
        reportChart.displayed = true;
        reportChart.data = data;

        reportChart.options = {
            title: 'My Expenses',
            is3D: true,
        };

        $scope.reportChart = reportChart;
        $scope.hideReport = false;
    });
}