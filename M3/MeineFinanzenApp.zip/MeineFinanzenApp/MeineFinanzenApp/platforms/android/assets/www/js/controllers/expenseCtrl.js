﻿var db = window.openDatabase('MeineFinanzen.db', '1.0', 'MeineFinanzen', '5 * 1024 * 1024');

var expenseCtrl = angular.module('starter.expenseCtrl', ['ngMaterial']);

expenseCtrl.controller('expenseCtrl', ['$scope', function ($scope) {
    $scope.tags = [];
    $scope.expenseDate = new Date();

    $scope.clearValue = function () {
        $scope.paymentType = {};
        $scope.tags = undefined;
    };
    $scope.save = function () {
        addExpense($scope, self.tags);
    };
}]);


//SQL Statements - nicht ctrl gebunden

function addExpense($scope, tags) {
    db.transaction(function (tx) {


        var dt = $scope.expenseDate;

        var dateF = dt.getFullYear() + '/' + dt.getMonth() + '/' + dt.getDate();


        tx.executeSql("INSERT INTO expense(paymentType,amount,tags,date) VALUES (?,?,?,?)", [$scope.paymentType, $scope.costs, $scope.tags, dateF], function (tx, result) {
            console.log(result);
        }, function (error) {
            console.log(error);
        });
    });
}
