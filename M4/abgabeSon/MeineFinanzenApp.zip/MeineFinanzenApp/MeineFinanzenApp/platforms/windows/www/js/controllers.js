var mainCtrl=angular.module('starter.controllers', ['ngMaterial']);

mainCtrl.controller('expenseCtrl',tagCtrl, function ($scope) {
    $scope.expenseDate = new Date();

    $scope.clearValue = function () {
        $scope.paymentType = undefined;
    };
    $scope.save = function () {
        alert('Form was valid!');
    };

})


function tagCtrl($timeout, $q) {
    var self = this;
    self.tags = [];
};