﻿var incomeCtrl = angular.module('starter.profilesCtrl', ['ngMaterial']);

var db = window.openDatabase('MeineFinanzen.db', '1.0', 'MeineFinanzen', '5 * 1024 * 1024');


incomeCtrl.controller('profilesCtrl', ['$scope', function ($scope) {
    $scope.clearValue = function () {
        $scope.name = ' ';
        $scope.lastName = ' ';
        $scope.profileType = {};
        $scope.profilename = ' ';

    };

    $scope.save = function () {
        createProfile($scope);
    };
}]);


//SQL Statements - nicht controller gebunden --

function createProfile($scope, tags) {
    db.transaction(function (tx) {
        tx.executeSql("INSERT INTO profiles(profileId,profileName,name,surename) VALUES (?,?,?,?)", [$scope.profileType, $scope.profilename, $scope.name, $scope.lastName], function (tx, result) {
            console.log(result);
        }, function (error) {
            console.log(error);
        });

        $scope.name = ' ';
        $scope.lastName = ' ';
        $scope.profileType = {};
        $scope.profilename = ' ';
    });
}