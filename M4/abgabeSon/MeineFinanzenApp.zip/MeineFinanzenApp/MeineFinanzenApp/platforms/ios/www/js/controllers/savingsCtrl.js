﻿var savingsCtrl = angular.module('starter.savingsCtrl', ['ngMaterial']);

var db = window.openDatabase('MeineFinanzen.db', '1.0', 'MeineFinanzen', '5 * 1024 * 1024');


savingsCtrl.controller('savingsCtrl', ['$scope', function ($scope) {
    $scope.result = false;
    $scope.targetDate = new Date();

    $scope.clearValue = function () {
        $scope.goal = " ";
        $scope.amount = 0;
    };

    $scope.save = function () {
        setTarget($scope);
    };
}]);


//SQL Statements - nicht controller gebunden --

function setTarget($scope) {
    db.transaction(function (tx) {

        var dt = $scope.targetDate;
        var dateF = dt.getFullYear() + '/' + dt.getMonth() + '/' + dt.getDate();

        tx.executeSql("INSERT INTO savings(target,amount,date) VALUES (?,?,?)", [$scope.goal, $scope.amount, dateF], function (tx, result) {
            $scope.goal = " ";
            $scope.amount = 0;
            $scope.targetDate = new Date();
            $scope.result = true;
        }, function (error) {
            console.log(error);
        });
    });
}