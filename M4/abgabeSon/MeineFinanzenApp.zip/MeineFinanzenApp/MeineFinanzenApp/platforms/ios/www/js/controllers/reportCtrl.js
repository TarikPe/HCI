﻿var reportCtrl = angular.module('starter.reportCtrl', ['ngMaterial', 'googlechart', 'starter.services']);
var db = window.openDatabase('MeineFinanzen.db', '1.0', 'MeineFinanzen', '5 * 1024 * 1024');


reportCtrl.controller('reportCtrl', function ($scope, sqlService) {
    
    $scope.hideReport = true;

    $scope.createReport = function () {

        var st = $scope.startDate;
        var startDate = st.getFullYear() + '/' + st.getMonth() + '/' + st.getDate();

        var ed = $scope.endDate;
        var endDate = ed.getFullYear() + '/' + ed.getMonth() + '/' + ed.getDate();


        var table = $scope.reportAbout;

        switch (parseInt(table)) {
            case 1: table = "expense";
                reportExpenses($scope, sqlService, startDate,endDate, table);
                break;
            case 2: table = "income";
                reportIncome($scope, sqlService, startDate, endDate, table);
                break;
            case 3: table = "savings";
                reportTargets($scope, sqlService, startDate, endDate, table);
                break;
            default:
                table = "expense";
        }

    };
  }).value('googleChartApiConfig', {
      version: '1.1',
      optionalSettings: {
          packages: ['bar'],
          language: 'en'
      }
  })

function reportIncome($scope, sqlService, startDate, endDate, table) {

    sqlService.createQuery(startDate, endDate, table).then(function (result) {
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Type');
        data.addColumn('number', 'Amount');

        console.log(result);

        for (i = 0; i < result.rows.length; ++i) {
            data.addRows([
                    [result.rows[i].incomeType, parseFloat(result.rows[i].amount)],
            ]);
        }

        generateReport($scope, data);
    });
}

function reportTargets($scope, sqlService, startDate, endDate, table) {

    sqlService.createQuery(startDate, endDate, table).then(function (result) {
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Target');
        data.addColumn('number', 'Amount');

        for (i = 0; i < result.rows.length; ++i) {
            data.addRows([
                    [result.rows[i].target, parseFloat(result.rows[i].amount)],
            ]);
        }

        generateReport($scope, data);
    });
}


function reportExpenses($scope, sqlService, startDate, endDate, table) {

    sqlService.createQuery(startDate, endDate, table).then(function (result) {
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Tags');
        data.addColumn('number', 'Amount');

        for (i = 0; i < result.rows.length; ++i) {
            data.addRows([
                    [result.rows[i].tags, parseFloat(result.rows[i].amount)],
            ]);
        }

        generateReport($scope, data);
    });
}

function generateReport($scope, data) {

    var reportChart = {};
    reportChart.type = $scope.reportType;
    reportChart.displayed = true;
    reportChart.data = data;

    reportChart.options = {
        is3D: true,
    };

    $scope.reportChart = reportChart;
    $scope.hideReport = false;
}
