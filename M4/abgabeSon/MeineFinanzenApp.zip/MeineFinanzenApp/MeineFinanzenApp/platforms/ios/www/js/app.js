var main = angular.module('starter', ['ionic', 'starter.services', 'starter.incomeCtrl', 'starter.expenseCtrl', 'starter.profilesCtrl', 'starter.savingsCtrl', 'starter.reportCtrl', 'ngMaterial', 'ngTagsInput', 'ngMessages', 'googlechart'])

.run(function ($ionicPlatform) {
  $ionicPlatform.ready(function() {
    if (cordova.platformId === 'ios' && window.cordova && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);

    }
    if (window.StatusBar) {
      StatusBar.styleDefault();
    }

      //Datenbank erstellung

    db = window.openDatabase('MeineFinanzen.db', '1.0', 'MeineFinanzen', '5 * 1024 * 1024');
    db.transaction(function (tx) {
        var createTables = new Array();
        createTables[0] = "CREATE TABLE IF NOT EXISTS expense (id integer primary key, paymentType text, amount text, tags text, date date)";
        createTables[1] =
            "CREATE TABLE IF NOT EXISTS income (id integer primary key, incomeType text, amount text, date date)";
        createTables[2] ="CREATE TABLE IF NOT EXISTS savings (id integer primary key, target text, amount text, date date)";
        createTables[3] ="CREATE TABLE IF NOT EXISTS profiles (id integer primary key, profileId integer,profileName text, name text, surename text)";

        for (table in createTables) {
            tx.executeSql(createTables[table], [], function (tx, result) {
               // console.log(result);
            }, function (error) {
                //console.log(error);
            });
        }
    });
  });
})

.config(function($stateProvider, $urlRouterProvider) {
  $stateProvider

    .state('app', {
    url: '/app',
    abstract: true,
    templateUrl: 'templates/menu.html'
  })

  .state('app.income', {
    url: '/income',
    views: {
      'menuContent': {
          templateUrl: 'templates/income.html',
          controller: 'incomeCtrl'
      }
    }
  })

  .state('app.expense', {
      url: '/expense',
      views: {
        'menuContent': {
            templateUrl: 'templates/expense.html',
            controller: 'expenseCtrl'
        }
      }
    })
  .state('app.profiles', {
      url: '/profiles',
    views: {
      'menuContent': {
          templateUrl: 'templates/profiles.html',
          controller: 'profilesCtrl'

      }
    }
  })
      .state('app.savings', {
          url: '/savings',
          views: {
              'menuContent': {
                  templateUrl: 'templates/savings.html',
                  controller: 'savingsCtrl'
              }
          }
      })
  .state('app.reports', {
      url: '/reports',
      views: {
          'menuContent': {
              templateUrl: 'templates/reports.html',
              controller: 'reportCtrl'
          }
      }
  });
  // if none of the above states are matched, use this as the fallback
  $urlRouterProvider.otherwise('/app/expense');
});