﻿var incomeCtrl = angular.module('starter.incomeCtrl', ['ngMaterial']);

var db = window.openDatabase('MeineFinanzen.db', '1.0', 'MeineFinanzen', '5 * 1024 * 1024');


incomeCtrl.controller('incomeCtrl', ['$scope', function ($scope) {
    $scope.result = false;

    $scope.incomeDate = new Date();

    $scope.clearValue = function () {
        $scope.incomeType = {};
        $scope.amount = 0;
    };

    $scope.save = function () {
        addIncome($scope);
    };
}]);


//SQL Statements - nicht controller gebunden --

function addIncome($scope, tags) {
    db.transaction(function (tx) {

        var dt = $scope.incomeDate;
        var dateF = dt.getFullYear() + '/' + dt.getMonth() + '/' + dt.getDate();

        tx.executeSql("INSERT INTO income(incomeType,amount,date) VALUES (?,?,?)", [$scope.incomeType, $scope.amount, dateF], function (tx, result) {
            $scope.incomeType = {};
            $scope.amount = 0;
            $scope.result = true;

        }, function (error) {
            console.log(error);
        });
    });
}